cubes = []
for value in range (1, 11):
    cubes.append(value**3)
    
print(cubes)
