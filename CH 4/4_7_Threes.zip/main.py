threes = []
for value in range (3, 11):
    threes.append(value*3)
    
print(threes)
